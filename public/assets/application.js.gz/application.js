<script type="text/javascript" src="/home/pawel/.rvm/gems/ruby-1.9.3-p194@rails3/gems/jquery-rails-2.0.0/vendor/assets/javascripts/jquery.js"></script>;
<script type="text/javascript" src="/home/pawel/.rvm/gems/ruby-1.9.3-p194@rails3/gems/jquery-rails-2.0.0/vendor/assets/javascripts/jquery_ujs.js"></script>;
<script type="text/javascript" src="/home/pawel/sample_app/.jhw-cache/coffee_script/home/pawel/sample_app/app/assets/javascripts/static_pages.js.coffee.js"></script>
            <script type="text/javascript">window.CSTF['static_pages.js.coffee.js'] = '/home/pawel/sample_app/app/assets/javascripts/static_pages.js.coffee';</script>;
<script type="text/javascript" src="/home/pawel/sample_app/app/assets/javascripts/application.js"></script>;
